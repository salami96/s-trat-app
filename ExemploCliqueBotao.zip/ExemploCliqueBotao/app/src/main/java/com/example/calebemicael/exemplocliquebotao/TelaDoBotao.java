package com.example.calebemicael.exemplocliquebotao;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TelaDoBotao extends AppCompatActivity {

    NotificationCompat.Builder notification;
    private static final int uniqueID = 45612;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_do_botao);

        final TextView campoTexto = (TextView) findViewById(R.id.campoTexto);
        Button botaoTexto = (Button)findViewById(R.id.botaoTexto);
        Button botaoCor = (Button)findViewById(R.id.botaoCor);
        Button botaoNotifique = (Button)findViewById(R.id.botaoNotifique);
        final ConstraintLayout fundoTela = (ConstraintLayout)findViewById(R.id.fundoTela);

        notification = new NotificationCompat.Builder(this, "BLAH");
        notification.setAutoCancel(true);





        botaoTexto.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                campoTexto.setText("Ola Mundo");
            }
        });

        botaoCor.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                fundoTela.setBackgroundColor(Color.parseColor("#ff00ff"));
            }
        });
    }

    public void notificationButtonAction(View view){
        // build the notification
        notification.setSmallIcon(android.R.drawable.ic_dialog_email);
        notification.setTicker("Hora de se cuidar!");
        notification.setWhen(System.currentTimeMillis());
        notification.setContentTitle("Tem remédio pra agora.");
        notification.setContentText("Hora de tomar Dorflex.");
        notification.setPriority(NotificationCompat.PRIORITY_MAX);
        notification.setVisibility(Notification.VISIBILITY_PUBLIC);

        // diz que, quando a notificacao for clicada, deve-se voltar para essa tela.
        Intent intent = new Intent(this, TelaDoBotao.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent, PendingIntent.FLAG_UPDATE_CURRENT);
        notification.setContentIntent(pendingIntent);


        notification.addAction(android.R.drawable.ic_dialog_email, "\uD83D\uDC4D TOMEI",
                pendingIntent);

        notification.addAction(android.R.drawable.arrow_down_float, "\u23F0 DEPOIS",
                pendingIntent);

        // Dispara a notificacao
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(uniqueID,notification.build());
    }

}
